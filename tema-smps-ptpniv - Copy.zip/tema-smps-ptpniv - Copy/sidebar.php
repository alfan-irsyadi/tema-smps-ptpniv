<html>
    <head>
        <link rel="style" href="style.css">
        <link rel="style" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"/>
    </head>
    <body>
        <!-- <div id="ttr_sidebar" class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <h2><?php _e('Categories'); ?></h2>
            <ul> <?php wp_list_cats('sort_column=namonthly'); ?> </ul>
            <h2><?php _e('Archives'); ?></h2>
            <ul> <?php wp_get_archives(); ?> </ul>
        </div> -->

        
    </body>
</html>


